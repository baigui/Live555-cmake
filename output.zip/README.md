# Live555-cmake
这是用于Android studio一个live555工程，编译脚本是gradle和cmake
